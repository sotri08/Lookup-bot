import discord
from discord.ext import commands, tasks
import requests
import json
import os
import aiofiles
import io
import datetime
from colorama import init as colorama_init

colorama_init()

TOKEN = 'MTI1MTg5MDY2MjIzNjg4NTA0Mg.GMDZU9.GXlPwhPGaS37uenNLgCWBpUVrDg4PZiZp-GxTc'  # Remplacez par votre propre token Discord
intents = discord.Intents.all()
bot = commands.Bot(command_prefix='+', intents=intents)
bot.remove_command('help')

CREDITS_PER_USE = 2  # Nombre de crédits nécessaires par utilisation
credit_system = {}  # Système de crédit initialisé comme un dictionnaire vide
EMBED_COLOR = 0xFFFFFF  # Couleur blanche pour les embeds

# Fonction pour sauvegarder les crédits dans un fichier JSON
def save_credits():
    try:
        with open('credit_system.json', 'w') as file:
            json.dump(credit_system, file, default=str)
        print("Crédits sauvegardés:", credit_system)  # Débogage : affiche les crédits sauvegardés
    except Exception as e:
        print(f"Erreur lors de la sauvegarde des crédits: {e}")

# Fonction pour charger les crédits depuis un fichier JSON
def load_credits():
    global credit_system
    try:
        with open('credit_system.json', 'r') as file:
            credit_system = json.load(file)
            print("Crédits chargés avec succès:", credit_system)  # Débogage : affiche les crédits chargés
    except FileNotFoundError:
        credit_system = {}
    except Exception as e:
        print(f"Erreur lors du chargement des crédits: {e}")

# Événement lorsque le bot est prêt
@bot.event
async def on_ready():
    print(f'{bot.user} est connecté!')
    bot.status = discord.Status.dnd
    activity = discord.Activity(type=discord.ActivityType.streaming, url="https://twitch.tv/klopontop", name=".gg/database")
    await bot.change_presence(activity=activity)
    load_credits()

# Événement lorsque le bot se déconnecte
@bot.event
async def on_disconnect():
    save_credits()

# Événement lorsqu'un message est envoyé
@bot.event
async def on_message(message):
    if message.author == bot.user:
        return
    if bot.user in message.mentions:
        await message.reply('👋 Mon prefix est `+`')
    await bot.process_commands(message)

# Commande pour réclamer les crédits quotidiens
@bot.command()
async def claim(ctx):
    global credit_system
    now = datetime.datetime.now()
    if ctx.author.id in credit_system and (now - datetime.datetime.fromisoformat(credit_system[ctx.author.id]["last_daily"])) < datetime.timedelta(days=1):
        await ctx.send("🚫 Vous avez déjà reçu vos crédits quotidiens.")
    else:
        if ctx.author.id not in credit_system:
            credit_system[ctx.author.id] = {"balance": 10, "last_daily": now.isoformat()}
        else:
            credit_system[ctx.author.id]["balance"] += 10
            credit_system[ctx.author.id]["last_daily"] = now.isoformat()

        embed = discord.Embed(title="🎉 Tu as reçu tes 10 crédits du jour!", color=EMBED_COLOR)
        embed.set_footer(text="© Database Searcher")
        embed.set_thumbnail(url="https://cdn.discordapp.com/icons/1214650139612942427/77a04a5cd346c80007dac1a89bf5aebe.webp?size=4096&format=webp&width=0&height=256")
        await ctx.send(embed=embed)
        save_credits()

# Commande pour ajouter des crédits à un utilisateur (réservée aux administrateurs)
@bot.command()
async def addcr(ctx, user: discord.Member, amount: int):
    authorized_ids = [1233484847335346296]  # Mettez les ID de vos administrateurs ici

    if ctx.author.id not in authorized_ids:
        await ctx.send("🚫 Désolé, vous n'êtes pas autorisé à ajouter des crédits.")
        return

    if user.id not in credit_system:
        credit_system[user.id] = {"balance": 0, "last_daily": None}
    credit_system[user.id]["balance"] += amount
    await ctx.send(f"✅ {user.mention} a maintenant {credit_system[user.id]['balance']} crédits.")
    save_credits()

# Commande pour afficher l'aide
@bot.command()
async def help(ctx):
    embed = discord.Embed(title="📜 Commandes", color=EMBED_COLOR)
    embed.set_footer(text="© Database Searcher")
    embed.set_thumbnail(url="https://cdn.discordapp.com/icons/1214650139612942427/77a04a5cd346c80007dac1a89bf5aebe.webp?size=4096&format=webp&width=0&height=256")
    embed.add_field(name="💡 Info", value="Les paramètres entre ``<>`` sont obligatoires. Utilisez ``+help`` si vous avez besoin d'aide.", inline=False)
    commands_list = [
        ("search", "🔍 Rechercher une personne dans les DB FiveM."),
        ("shein", "🔍 Rechercher une personne dans les DB Shein."),
        ("intelx", "🔍 Rechercher une personne dans les DB Intelx."),
        ("doxbin", "🔍 Rechercher une personne dans les DB Doxbin."),
        ("onlyfan", "🔍 Rechercher une personne dans les DB OnlyFan."),
        ("mastercard", "🔍 Rechercher une personne dans les DB Mastercard."),
        ("paypal", "🔍 Rechercher une personne dans les DB Paypal."),
        ("tebex", "🔍 Rechercher une personne dans les DB Tebex."),
        ("discordd", "🔍 Rechercher une personne dans les DB Discord."),
        ("steam", "🔍 Rechercher une personne dans les DB Steam."),
        ("epicgames", "🔍 Rechercher une personne dans les DB Epic Games."),
        ("orange", "🔍 Rechercher une personne dans les DB Orange."),
        ("allo", "🔍 Rechercher une personne dans les DB Allo."),
        ("claim", "🎁 Récupérer ses 10 crédits du jour."),
        ("balance", "💰 Voir son solde de crédits."),
        ("snusbase", "🔍 Rechercher un mot-clé grâce à SnusBase."),
        ("addcr <id> <cr>", "⚙️ Ajouter des crédits à un utilisateur. (Admin seulement)")
    ]
    for name, desc in commands_list:
        embed.add_field(name=f"``+{name} <mot-clé>``", value=desc, inline=False)
    await ctx.send(embed=embed)

# Fonction asynchrone pour effectuer une recherche dans une base de données spécifique
async def perform_search(ctx, query, directory):
    if ctx.author.id not in credit_system or credit_system[ctx.author.id]["balance"] < CREDITS_PER_USE:
        await ctx.send("🚫 Vous n'avez pas assez de crédits pour utiliser cette commande. Merci de contacter un Fondateur pour obtenir plus de crédits.")
        return

    await ctx.send(f'⏳ Veuillez patienter pendant que je rassemble les informations...')
    result = []

    try:
        for file in os.listdir(directory):
            with open(os.path.join(directory, file), "r", encoding='utf-8') as f:
                lines = f.readlines()
                for line in lines:
                    if query in line:
                        result.append(line.strip())

        if result:
            async with aiofiles.open('results.txt', 'w', encoding='utf-8') as f:
                await f.write('\n'.join(result))

            with open('results.txt', 'rb') as f:
                await ctx.author.send(file=discord.File(f))
            await ctx.send(f'📬 Les résultats ont été envoyés en message privé.')
            credit_system[ctx.author.id]["balance"] -= CREDITS_PER_USE
        else:
            await ctx.send(f'❌ Aucun résultat trouvé pour: {query}')
    except Exception as e:
        await ctx.send(f"⚠️ Erreur lors de la recherche: {e}")
    save_credits()

# Commandes pour effectuer des recherches dans des bases de données spécifiques
@bot.command()
async def search(ctx, *, query):
    await perform_search(ctx, query, "database")

@bot.command()
async def mastercard(ctx, *, query):
    await perform_search(ctx, query, "mastercard")

@bot.command()
async def shein(ctx, *, query):
    await perform_search(ctx, query, "shein")

@bot.command()
async def onlyfan(ctx, *, query):
    await perform_search(ctx, query, "onlyfan")

@bot.command()
async def intelx(ctx, *, query):
    await perform_search(ctx, query, "intelx")

@bot.command()
async def tebex(ctx, *, query):
    await perform_search(ctx, query, "tebex")

@bot.command()
async def doxbin(ctx, *, query):
    await perform_search(ctx, query, "doxbin")

@bot.command()
async def paypal(ctx, *, query):
    await perform_search(ctx, query, "paypal")

@bot.command()
async def discordd(ctx, *, query):
    await perform_search(ctx, query, "discord")

@bot.command()
async def steam(ctx, *, query):
    await perform_search(ctx, query, "steam")

@bot.command()
async def epicgames(ctx, *, query):
    await perform_search(ctx, query, "epicgames")

@bot.command()
async def orange(ctx, *, query):
    await perform_search(ctx, query, "orange")

@bot.command()
async def allo(ctx, *, query):
    await perform_search(ctx, query, "allo")

# Commande pour effectuer une recherche sur SnusBase
@bot.command()
async def snusbase(ctx, *, query):
    if ctx.author.id not in credit_system or credit_system[ctx.author.id]["balance"] < CREDITS_PER_USE:
        await ctx.send("🚫 Vous n'avez pas assez de crédits pour utiliser cette commande. Merci de contacter un Fondateur.")
        return

    await ctx.send(f'⏳ Veuillez patienter pendant que je rassemble les informations...')
    
    api_url = "https://beta.snusbase.com/api/search"
    api_key = "votre_cle_api_snusbase"  # Remplacez par votre clé API SnusBase

    params = {
        "query": query,
        "key": api_key
    }

    response = requests.get(api_url, params=params)

    if response.status_code == 200:
        results = response.json()
        formatted_response = json.dumps(results, indent=4)
        output = io.BytesIO()
        output.write(formatted_response.encode())
        output.seek(0)
        await ctx.author.send(file=discord.File(output, 'snusbase_results.json'))
        await ctx.send(f'📬 Les résultats ont été envoyés en message privé.')
        credit_system[ctx.author.id]["balance"] -= CREDITS_PER_USE
    else:
        await ctx.send(f"⚠️ Erreur lors de la recherche sur Snusbase: {response.status_code}")
    save_credits()

# Commande pour afficher le solde de crédits d'un utilisateur
@bot.command()
async def balance(ctx):
    if ctx.author.id not in credit_system:
        await ctx.send("Vous n'avez pas encore de crédits. Utilisez `+claim` pour obtenir des crédits quotidiens.")
    else:
        balance = credit_system[ctx.author.id]["balance"]
        await ctx.send(f"💰 Vous avez {balance} crédits.")

# Lancer le bot avec le token spécifié
bot.run(TOKEN)